package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.AbstractApplicationContext;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import com.example.dto.*;
import com.example.Services.MovieServices;


@SpringBootApplication
public class MovieApplication {
	public static void main(String[] args) {
		AbstractApplicationContext context = (AbstractApplicationContext)SpringApplication.run(MovieApplication.class, args);
	    
		
		MovieServices service = (MovieServices)context.getBean("movieservice");
		//Insert 
		MovieDTO dto = new MovieDTO("BNC",LocalDate.now(),LocalDateTime.now());
		List<DirectorDTO> directorList = Arrays.asList(
				new DirectorDTO("RAJAMOLI", "SSS", "Hyderabad","raja@rrr.com",987654321L),
				new DirectorDTO("RAJKUMAR","HIRA","Mumbai","richard@mumbai.com",9089786734L)
				);
	
		
		
		service.add(dto,directorList);  		
        service.searchBasedOnTitle("RAJAMOLI");
        
        
        
        
        /**
         * Get all Directors from Movie Title
         */
        System.out.println(" Get all Directors from Movie Title");
        
        service.getDirectorListFromTitle("RAJAMOLI");
        
        /**
         * Get all Movies from Director Name
         */
        System.out.println("Get all Movies from Director Name");
        service.getMovieListFromDirectorName("RAJKUMAR");
        
        
        //Get All movies
        //Display Log At Info Level
        System.out.println(service.displayAll().toString());       
	}


}
